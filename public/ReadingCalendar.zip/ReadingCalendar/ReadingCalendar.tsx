import React, { useState } from "react";
import styles from "./ReadingCalendar.module.css";
import book1 from "./book1.png";
import book2 from "./book2.png";
import book3 from "./book3.png";
import book4 from "./book4.png";
import { ReactComponent as ArrowLeft } from "../MainBanner/arrowleft.svg";
import { ReactComponent as ArrowRight } from "../MainBanner/arrowright.svg";

interface BookRecord {
  id: number;
  title: string;
  author: string;
  date: string;
  thumbnail: string;
}

interface DailyRecord {
  date: Date;
  records: BookRecord[];
}

// 샘플 데이터
const sampleRecords: DailyRecord[] = [
  {
    date: new Date(2025, 10, 3), //11월
    records: [
      { id: 1, title: "죽고 싶지만 떡볶이는 먹고 싶어", author: "백세희", date: "25.11.03", thumbnail: book3 },
    ],
  },
  {
    date: new Date(2025, 10, 6),
    records: [
      { id: 2, title: "사탄탱고", author: "크러스너호르커이 라슬로", date: "25.11.06", thumbnail: book1 },
    ],
  },
  {
    date: new Date(2025, 10, 7),
    records: [
      { id: 3, title: "사탄탱고", author: "크러스너호르커이 라슬로", date: "25.11.07", thumbnail: book1 },
    ],
  },
  {
    date: new Date(2025, 10, 10),
    records: [
      { id: 4, title: "저소비생활", author: "가제노타미", date: "25.11.10", thumbnail: book2 },
    ],
  },
  {
    date: new Date(2025, 10, 11),
    records: [
      { id: 5, title: "삼체 1부", author: "류츠신", date: "25.11.11", thumbnail: book4 },
    ],
  },
];

const WEEKDAYS = ["일", "월", "화", "수", "목", "금", "토"];

const ReadingCalendar: React.FC = () => {
  const [currentYear, setCurrentYear] = useState(2025);
  const [currentMonth, setCurrentMonth] = useState(10); // 0 = 1월
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentYear(currentYear - 1);
      setCurrentMonth(11);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
    setSelectedDay(null);
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentYear(currentYear + 1);
      setCurrentMonth(0);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
    setSelectedDay(null);
  };

  // 달력 날짜 생성
  const firstDay = new Date(currentYear, currentMonth, 1);
  const lastDay = new Date(currentYear, currentMonth + 1, 0);
  const days: (Date | null)[] = [];

  for (let i = 0; i < firstDay.getDay(); i++) days.push(null);
  for (let d = 1; d <= lastDay.getDate(); d++) days.push(new Date(currentYear, currentMonth, d));
  while (days.length < 42) days.push(null);

  const onDateClick = (date: Date | null) => {
    if (!date) return;
    setSelectedDay((prev) => (prev?.getTime() === date.getTime() ? null : date));
  };

  const selectedMonthRecords = selectedDay
    ? sampleRecords
        .filter(
          (rec) =>
            rec.date.getFullYear() === selectedDay.getFullYear() &&
            rec.date.getMonth() === selectedDay.getMonth()
        )
        .flatMap((r) => r.records)
    : [];

  return (
    <div className={styles.calendarWrapper}>
      <h3 className={styles.title}>독서기록</h3>

      {/* 월 이동 헤더 */}
      <div className={styles.header}>
        <button className={styles.navButton} onClick={prevMonth}>
          <ArrowLeft className={styles.arrowIcon} />
        </button>
        <span>{currentMonth + 1}월</span>
        <button className={styles.navButton} onClick={nextMonth}>
          <ArrowRight className={styles.arrowIcon} />
        </button>
      </div>

      {/* 요일 */}
      <div className={styles.weekdaysGrid}>
        {WEEKDAYS.map((wd) => (
          <div
            key={wd}
            className={`${styles.dayLabel} ${wd === "일" ? styles.sun : wd === "토" ? styles.sat : ""}`}
          >
            {wd}
          </div>
        ))}
      </div>

      {/* 날짜 그리드 */}
      <div className={styles.datesGrid}>
        {days.map((day, idx) => {
          if (!day) {
            return <div key={"empty-" + idx} className={`${styles.dateCell} ${styles.disabled}`} />;
          }

          const dayRecord = sampleRecords.find(
            (rec) =>
              rec.date.getFullYear() === day.getFullYear() &&
              rec.date.getMonth() === day.getMonth() &&
              rec.date.getDate() === day.getDate()
          );

          const isSelected = selectedDay?.getTime() === day.getTime();

          return (
            <div
              key={day.toISOString()}
              className={`${styles.dateCell} ${dayRecord ? styles.hasRecord : ""}`}
              onClick={() => onDateClick(day)}
            >
              <div
                className={styles.dateNumber}
                style={{
                  color:
                    day.getDay() === 0 ? "#CC1D1D" : day.getDay() === 6 ? "#0034B9" : "inherit",
                }}
              >
                {day.getDate()}
              </div>

              {dayRecord && (
                <img
                  src={dayRecord.records[0].thumbnail}
                  alt="책 표지"
                  className={styles.recordThumbnail}
                />
              )}

              {isSelected && dayRecord && selectedMonthRecords.length > 0 && (
                <div className={styles.overlayTab}>
                  {selectedMonthRecords.map((rec) => (
                    <div key={rec.id} className={styles.overlayTabItem}>
                      <img src={rec.thumbnail} alt="책 표지" className={styles.bookThumbnail} />
                      <div className={styles.bookInfo}>
                        <div className={styles.bookTitle}>{rec.title}</div>
                        <div className={styles.bookAuthor}>{rec.author}</div>
                        <div className={styles.bookDate}>{rec.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ReadingCalendar;
